export { default } from './PortletContent';
