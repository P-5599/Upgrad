export { default } from './CinemasPage';
