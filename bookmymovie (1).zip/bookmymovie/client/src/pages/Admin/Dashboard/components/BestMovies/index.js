export { default } from './BestMovies';
