export { default } from './TotalCinemas';
