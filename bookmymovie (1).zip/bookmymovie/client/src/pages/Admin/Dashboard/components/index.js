export { default as TotalUsers } from './TotalUsers';
export { default as TotalCinemas } from './TotalCinemas';
export { default as TotalMovies } from './TotalMovies';
export { default as TotalReservations } from './TotalReservations';
export { default as BestMovies } from './BestMovies';
export { default as UsersByDevice } from './UsersByDevice';
