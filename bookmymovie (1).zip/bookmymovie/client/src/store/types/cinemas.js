export const GET_CINEMAS = 'GET_CINEMAS';
export const GET_CINEMA = 'GET_CINEMA';
export const SELECT_CINEMA = 'SELECT_CINEMA';
export const CREATE_CINEMA = 'CREATE_CINEMA';
