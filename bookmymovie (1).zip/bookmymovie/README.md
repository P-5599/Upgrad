
$ npm install
$ cd server npm install && npm start
$ cd client npm install && npm start
```
Start the server.

```sh
$ cd server 
$ npm install 
```

Start the client.

```sh
$ cd client 
$ npm install 
$ npm start
```

Start from root path
```sh
$ npm run server
$ npm run client
```
# bookmymovie-upgrad
